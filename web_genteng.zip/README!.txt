!IMPORTANT!

Untuk mengakses laman admin, gunakan kolom search localhost/web_genteng/admin/

username : admin
password : admin123

Jangan lupa import database kedalam phpmyadmin jika menggunakan xammp dengan nama database "genteng".